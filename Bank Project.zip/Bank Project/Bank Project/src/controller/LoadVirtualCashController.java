package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import models.LoginDatabaseOperations;

public class LoadVirtualCashController implements Initializable{
	@FXML
	private Label labelWelcomeMessage;
	@FXML
	private MenuItem menuForexAccount, menuProfile,viewPayUpTransactions,transferFunds,linkCreditCards,unlinkCreditCards,addPayee,removePayee,addVirtualCard;
	@FXML
	private TextField txtVirtualCardNumber,txtVirtualCardCVV,txtRechargeAmount,txtCreditCardAlias,txtCVV;
	@FXML
	private ComboBox<String> comboRechargeAccount = new ComboBox<>();
	@FXML
	private ComboBox<String> comboCreditCardAlias = new ComboBox<>();
	@FXML
	private Label labelAlias,labelCreditCardCVV;
	@FXML
	private Stage stage;
	@FXML
	private Parent root;

	private LoginDatabaseOperations loginDatabaseOperations;
	private ResultSet resultSet;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		loginDatabaseOperations = new LoginDatabaseOperations();

		List<String> list = new ArrayList<String>();
		list.add("Credit Card");
		list.add("Bank Account");

		ObservableList<String> obList = FXCollections.observableList(list);
		comboRechargeAccount.getItems().clear();
		comboRechargeAccount.setItems(obList);

		getVirtualCard();
		comboCreditCardAlias.setVisible(false);
		
		comboRechargeAccount.getSelectionModel().selectedItemProperty()
		.addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
				// TODO Auto-generated method stub
				try {

					System.out.println("Value is: "+arg2);

					if(arg2.equalsIgnoreCase("Credit Card")){
						List<String> cards = new ArrayList<>();
						labelAlias.setVisible(true);
						comboCreditCardAlias.setVisible(true);
						labelCreditCardCVV.setVisible(true);
						txtCVV.setVisible(true);

						resultSet = loginDatabaseOperations.selectAllCards(AccountHolderController.AccountNo);
						while(resultSet.next()){
							cards.add(resultSet.getString(2));
						}

						ObservableList<String> obList = FXCollections.observableList(cards);
						comboCreditCardAlias.getItems().clear();
						comboCreditCardAlias.setItems(obList);
					}
					else if(arg2.equalsIgnoreCase("Bank Account")){
						labelAlias.setVisible(false);
						comboCreditCardAlias.setVisible(false);
						labelCreditCardCVV.setVisible(false);
						txtCVV.setVisible(false);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		});
	}

	private void getVirtualCard() {
		try {
			resultSet = loginDatabaseOperations.getVirtualCardNumber(AccountHolderController.AccountNo);
			while(resultSet.next()){
				txtVirtualCardNumber.setText(resultSet.getString(2)+""+resultSet.getString(3)+""+resultSet.getString(4)+""+resultSet.getString(5));
				txtVirtualCardCVV.setText(resultSet.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException, SQLException{
		if(event.getSource()==menuForexAccount){
			//get reference to the button's stage         
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			//load up OTHER FXML document
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
			root = fxmlLoader.load();
			ForexAccountController controller = fxmlLoader.<ForexAccountController>getController();
			controller.initData(labelWelcomeMessage.getText().toString());
		}
		else if(event.getSource()==menuProfile){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/ViewProfile.fxml"));
		}
		else if(event.getSource()==viewPayUpTransactions){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/PayUpTransactions.fxml"));
		}

		else if(event.getSource()==transferFunds){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/TransferFunds.fxml"));
		}
		else if(event.getSource()==linkCreditCards){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/LinkDebitCreditCards.fxml"));
		}

		/*		else if(event.getSource()==unlinkCreditCards){
		       stage=(Stage) labelWelcomeMessage.getScene().getWindow();
		  root = FXMLLoader.load(getClass().getResource("/fxml/UnlinkCreditDebitCards.fxml"));
		      }
		 */		else if(event.getSource()==addPayee){
			 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			 root = FXMLLoader.load(getClass().getResource("/fxml/AddPayee.fxml"));
		 }

		 else if(event.getSource()==removePayee){
			 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
			 root = fxmlLoader.load();

			 RemovePayeeController controller = fxmlLoader.<RemovePayeeController>getController();
			 controller.initData(labelWelcomeMessage.getText().toString());

		 }
		 else if(event.getSource()==addVirtualCard){
			 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/AddVirtualCard.fxml"));
			 root = fxmlLoader.load();

			 AddVirtualCardController controller = fxmlLoader.<AddVirtualCardController>getController();
			 controller.initData(labelWelcomeMessage.getText().toString());
		 }

		//create a new scene with root and set the stage
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void saveData(){
		try{
			/*			payee = new ArrayList<>();
			payee.add(0, txtPayeeName.getText().toString());
			payee.add(1, txtPayeeAccNumber.getText().toString());
			payee.add(2, txtPayeeAlias.getText().toString());
			payee.add(3, txtPayeeContact.getText().toString());
			payee.add(4, AccountHolderController.AccountNo.toString());

			loginDatabaseOperations.insertPayee(payee);
			 */
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void initData(String string) {
		// TODO Auto-generated method stub
		labelWelcomeMessage.setText(string);
	}
	
	
}
