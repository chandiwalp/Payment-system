package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import models.LoginDatabaseOperations;

public class LinkCreditCardController implements Initializable {

	@FXML
	private TextField txtCreditCardNumber,txtCVVNumber,txtNameOnCard,txtMonth,txtYear,txtAlias,txtCreditCardType;
	@FXML
	private Label labelWelcomeMessage;	
	@FXML
	private MenuItem menuForexAccount, menuProfile,viewPayUpTransactions,transferFunds,linkCreditCards,unlinkCreditCards,addPayee,removePayee,addVirtualCard;
	@FXML
	private Stage stage;
	@FXML
	private Parent root;
	@FXML
	private ListView<String> listView;
	
	private List<String> cardList;
	
	ObservableList<String> observableList =  FXCollections.observableArrayList();
	
	private LoginDatabaseOperations loginDatabaseOperations;

	private List<String> creditCard;
	private ResultSet resultSet;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		loginDatabaseOperations = new LoginDatabaseOperations();
		try {
		resultSet = loginDatabaseOperations.selectAllCards(AccountHolderController.AccountNo);
		cardList = new ArrayList<>();
			while(resultSet.next()){
				cardList.add(0,resultSet.getString(1));
				cardList.add(1,resultSet.getString(2));
				cardList.add(2,resultSet.getString(3));
				cardList.add(3,resultSet.getString(4));
			}
			
			observableList.setAll(cardList);
			listView.setItems(observableList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setCreditCardType(){
		try{
			System.out.println(txtCreditCardNumber.getLength());
			if(txtCreditCardNumber.getLength() >= 16){
				System.out.println(txtCreditCardNumber.getText());
				String result = getCCType(txtCreditCardNumber.getText().trim());
				System.out.println(result);
				if(result == "NA")
					new Alert(Alert.AlertType.ERROR, "Invalid Card").showAndWait();
				else
				txtCreditCardType.setText(result);	
			}
			else
			{
				//do nothing
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	private String getCCType(String ccNumber){

		String visaRegex        = "^4[0-9]{12}(?:[0-9]{3})?$";
		String masterRegex      = "^5[1-5][0-9]{14}$";
		String discoverRegex    = "^6(?:011|5[0-9]{2})[0-9]{12}$";
		String CCType 			= "";

		String regex = "^(?:(?<visa>4[0-9]{12}(?:[0-9]{3})?)|" +
				"(?<mastercard>5[1-5][0-9]{14})|" +
				"(?<discover>6(?:011|5[0-9]{2})[0-9]{12})|" +
				"(?<amex>3[47][0-9]{13})|" +
				"(?<diners>3(?:0[0-5]|[68][0-9])?[0-9]{11})|" +
				"(?<jcb>(?:2131|1800|35[0-9]{3})[0-9]{11}))$";

		try {
			/*            ccNumber = ccNumber.replaceAll("\\D", "");
            	if(ccNumber.matches(visaRegex))
            		return "VISA";
            	else if(ccNumber.matches(masterRegex))
            		return "MASTER CARD";
            	else if(ccNumber.matches(discoverRegex))
            		return "DISCOVER";
            	else 
            		return "";
			 */            	
			Pattern pattern = Pattern.compile(regex);
			ccNumber = ccNumber.replaceAll("\\D", "");
			Matcher matcher = pattern.matcher(ccNumber);
			System.out.println(matcher.matches());
			if(matcher.matches()) {
				//If card is valid then verify which group it belong 
				if(matcher.group("mastercard")!= null){
					System.out.println("mastercard");
					CCType = "MASTER CARD";
				}
				else if(matcher.group("visa") != null){
					System.out.println("visa");
					CCType = "VISA";
				}
				else if(matcher.group("discover") != null){
					System.out.println("discover");
					CCType = "DISCOVER";
				}
				else if(matcher.group("amex") != null){
					System.out.println("amex");
					CCType = "AMEX";
				}
				else if(matcher.group("diners") != null){
					System.out.println("diners");
					CCType = "DINERS";
				}
			}
			else{
				CCType = "NA";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CCType;
	}

	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException, SQLException{
		if(event.getSource()==menuForexAccount){
			//get reference to the button's stage         
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			//load up OTHER FXML document
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
			root = fxmlLoader.load();
			ForexAccountController controller = fxmlLoader.<ForexAccountController>getController();
			controller.initData(labelWelcomeMessage.getText().toString());

		}
		else if(event.getSource()==menuProfile){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/ViewProfile.fxml"));
		}
		else if(event.getSource()==viewPayUpTransactions){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/PayUpTransactions.fxml"));
		}

		else if(event.getSource()==transferFunds){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/TransferFunds.fxml"));
		}
		else if(event.getSource()==linkCreditCards){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/LinkDebitCreditCards.fxml"));
		}

/*		else if(event.getSource()==unlinkCreditCards){
		       stage=(Stage) labelWelcomeMessage.getScene().getWindow();
		  root = FXMLLoader.load(getClass().getResource("/fxml/UnlinkCreditDebitCards.fxml"));
		      }
*/		else if(event.getSource()==addPayee){
		       stage=(Stage) labelWelcomeMessage.getScene().getWindow();
		  root = FXMLLoader.load(getClass().getResource("/fxml/AddPayee.fxml"));
		      }

else if(event.getSource()==removePayee){
    stage=(Stage) labelWelcomeMessage.getScene().getWindow();
	FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
	root = fxmlLoader.load();

	RemovePayeeController controller = fxmlLoader.<RemovePayeeController>getController();
	controller.initData(labelWelcomeMessage.getText().toString());

   }
		//create a new scene with root and set the stage
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void saveData(){
		try{
			creditCard = new ArrayList<>();
			
			creditCard.add(0, txtCreditCardNumber.getText().toString());
			creditCard.add(1, txtCVVNumber.getText().toString());
			creditCard.add(2, txtNameOnCard.getText().toString());
			creditCard.add(3, txtMonth.getText().toString()+"/"+txtYear.getText().toString());
			creditCard.add(4, txtAlias.getText().toString());
			creditCard.add(5, txtCreditCardType.getText().toString());
			creditCard.add(6, AccountHolderController.AccountNo.toString());
				if(loginDatabaseOperations.insertCreditCard(creditCard)){
					System.out.println("Linked...");
				}
				else
					System.out.println("Not Linked...");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}