package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import models.LoginDatabaseOperations;

public class LoginController {

	@FXML
	private Label lblStatus;
	@FXML
	private TextField txtUsername,txtPassword;

	private ResultSet resultSet = null;
	private LoginDatabaseOperations loginDatabaseOperations;
	private static int no_of_attempts = 3;

	public void Login(ActionEvent event) {
		String password = "";
		char active_yn = 'N';
		int returnCode;
		loginDatabaseOperations = new LoginDatabaseOperations();

		try {
			resultSet = loginDatabaseOperations.selectData(txtUsername.getText().toString().trim());

			while(resultSet.next()){
				password = resultSet.getString(1);
				active_yn = resultSet.getString(2).charAt(0);
			}
			if(active_yn == 'Y'){
				if(password.equals(LoginDatabaseOperations.getMD5(txtPassword.getText()))){
					new Alert(Alert.AlertType.CONFIRMATION, "Login Successful...").showAndWait();			 
					FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/AccountHolderConsole.fxml"));
					Parent root1 = (Parent) fxmlLoader.load();
					Stage stage = new Stage();
					stage.initModality(Modality.APPLICATION_MODAL);
					stage.initStyle(StageStyle.UNDECORATED);
					stage.setTitle("Account Console");
					stage.setScene(new Scene(root1));

					AccountHolderController controller = fxmlLoader.<AccountHolderController>getController();
					controller.initData(txtUsername.getText().toString().trim());

					stage.show();
				}
				else{
					--no_of_attempts;
					if(no_of_attempts > 0){
						new Alert(Alert.AlertType.ERROR, "Login Unsuccessful. You have " +no_of_attempts +" login attempts left.").showAndWait();
						txtPassword.setText("");
						txtPassword.requestFocus();
					}
					else
					{
						new Alert(Alert.AlertType.ERROR, "Your account is blocked. Please contact the bank representative.").showAndWait();
						returnCode = loginDatabaseOperations.updateLoginTableAfterMaxAttempts(txtUsername.getText().toString().trim());
					}
				}
			}

			else{
				new Alert(Alert.AlertType.ERROR, "Your account is blocked or you do not have online access. Please contact the bank representative.").showAndWait();
				System.exit(0);
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			loginDatabaseOperations.closeConnection();
		}
	}

	public void CreateAccount(ActionEvent event) {
		// TODO Auto-generated method stub
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/CreateAccount.fxml"));
			Parent root1;
			root1 = (Parent) fxmlLoader.load();
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.initStyle(StageStyle.UNDECORATED);
			stage.setTitle("ABC");
			stage.setScene(new Scene(root1));  
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}