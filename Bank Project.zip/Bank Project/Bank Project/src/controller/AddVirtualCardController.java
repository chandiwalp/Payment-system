package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import datamodels.Currency;
import datamodels.VirtualCard;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.LoginDatabaseOperations;

public class AddVirtualCardController implements Initializable {

	@FXML
	private Label labelDigits1,labelDigits2,labelDigits3,labelDigits4,labelCardHolderName,labelCVV,labelWelcomeMessage;
	@FXML
	private MenuItem menuForexAccount, menuProfile,viewPayUpTransactions,transferFunds,linkCreditCards,unlinkCreditCards,addPayee,removePayee,addVirtualCard;
	@FXML
	private Stage stage;
	@FXML
	private Parent root;
	@FXML
	private Button btnAdd;

	private ResultSet resultSet = null;
	private LoginDatabaseOperations loginDatabaseOperations;


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

		loginDatabaseOperations = new LoginDatabaseOperations();	
	}

	public void initData(String string) {
		// TODO Auto-generated method stub
		labelWelcomeMessage.setText(string);
		parseUserList();
	}

	public void parseUserList() {
		// TODO Auto-generated method stub		
		ResultSet rs;
		try {
			resultSet = loginDatabaseOperations.getVirtualCardYN(AccountHolderController.AccountNo);
				while(resultSet.next()){
					if(resultSet.getString(1).equalsIgnoreCase("N"))
					{
						//getNewVirtualCardNumber()
						rs = loginDatabaseOperations.getNewVirtualCardNumber(AccountHolderController.AccountNo);
						while(rs.next()){
							System.out.println(rs.getString(1)+""+rs.getString(2));
							labelDigits1.setText(rs.getString(1));
							labelDigits2.setText(rs.getString(2));
							labelDigits3.setText(rs.getString(3));
							labelDigits4.setText(rs.getString(4));
							labelCVV.setText(rs.getString(5));
							labelCardHolderName.setText(rs.getString(6).toUpperCase());
						}
					}
					else if(resultSet.getString(1).equalsIgnoreCase("Y")){
						//getVirtualCardNumber()
						
						rs = loginDatabaseOperations.getVirtualCardNumber(AccountHolderController.AccountNo);
						while(rs.next()){
							System.out.println(rs.getString(2)+""+rs.getString(3));
							labelDigits1.setText(rs.getString(2));
							labelDigits2.setText(rs.getString(3));
							labelDigits3.setText(rs.getString(4));
							labelDigits4.setText(rs.getString(5));
							labelCVV.setText(rs.getString(6));
							labelCardHolderName.setText(rs.getString(7).toUpperCase());
							btnAdd.setText("Remove");
						}

					}
				}
/*				resultSet = loginDatabaseOperations.getNewVirtualCardNumber(AccountHolderController.AccountNo);
				while(resultSet.next()){
									currencies.add(0,resultSet.getString(1));
				currencies.add(1,resultSet.getString(2));
				cardList.add(2,resultSet.getString(3));
				cardList.add(3,resultSet.getString(4));
					 
					if(resultSet.getString(1).length() == 3 || resultSet.getString(2).length() == 3
							|| resultSet.getString(3).length() == 3 || resultSet.getString(4).length() == 3
							|| resultSet.getString(5).length() == 2)
					{
						if(resultSet.getString(1).length() == 3)
						{
							labelDigits1.setText(resultSet.getString(1)+"0");
							labelDigits2.setText(resultSet.getString(2));
							labelDigits3.setText(resultSet.getString(3));
							labelDigits4.setText(resultSet.getString(4));
							labelCVV.setText(resultSet.getString(5));
							labelCardHolderName.setText(resultSet.getString(6).toUpperCase());
						}
						else if(resultSet.getString(2).length() == 3){
							labelDigits1.setText(resultSet.getString(1));
							labelDigits2.setText(resultSet.getString(2)+"0");
							labelDigits3.setText(resultSet.getString(3));
							labelDigits4.setText(resultSet.getString(4));
							labelCVV.setText(resultSet.getString(5));
							labelCardHolderName.setText(resultSet.getString(6).toUpperCase());
						}
						else if(resultSet.getString(3).length() == 3){
							labelDigits1.setText(resultSet.getString(1));
							labelDigits2.setText(resultSet.getString(2));
							labelDigits3.setText(resultSet.getString(3)+"0");
							labelDigits4.setText(resultSet.getString(4));
							labelCVV.setText(resultSet.getString(5));
							labelCardHolderName.setText(resultSet.getString(6).toUpperCase());
						}
						else if(resultSet.getString(4).length() == 3){
							labelDigits1.setText(resultSet.getString(1));
							labelDigits2.setText(resultSet.getString(2));
							labelDigits3.setText(resultSet.getString(3));
							labelDigits4.setText(resultSet.getString(4)+"0");
							labelCVV.setText(resultSet.getString(5));
							labelCardHolderName.setText(resultSet.getString(6).toUpperCase());
						}
						else if(resultSet.getString(4).length() == 2){
							labelDigits1.setText(resultSet.getString(1));
							labelDigits2.setText(resultSet.getString(2));
							labelDigits3.setText(resultSet.getString(3));
							labelDigits4.setText(resultSet.getString(4));
							labelCVV.setText(resultSet.getString(5)+"0");
							labelCardHolderName.setText(resultSet.getString(6).toUpperCase());
						}
					}
					else
					{
						labelDigits1.setText(resultSet.getString(1));
						labelDigits2.setText(resultSet.getString(2));
						labelDigits3.setText(resultSet.getString(3));
						labelDigits4.setText(resultSet.getString(4));
						labelCVV.setText(resultSet.getString(5));
						labelCardHolderName.setText(resultSet.getString(6).toUpperCase());
					}
				}

				btnAdd.setText("Add");
*/		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException{
		if(event.getSource()==menuForexAccount){
			//get reference to the button's stage         
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			//load up OTHER FXML document
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
			root = fxmlLoader.load();
			ForexAccountController controller = fxmlLoader.<ForexAccountController>getController();
			controller.initData(labelWelcomeMessage.getText().toString());
		}
		else if(event.getSource()==menuProfile){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/ViewProfile.fxml"));
		}
		else if(event.getSource()==viewPayUpTransactions){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/PayUpTransactions.fxml"));
		}

		else if(event.getSource()==transferFunds){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/TransferFunds.fxml"));
		}
		else if(event.getSource()==linkCreditCards){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/LinkDebitCreditCards.fxml"));
		}

		/*		else if(event.getSource()==unlinkCreditCards){
		       stage=(Stage) labelWelcomeMessage.getScene().getWindow();
		  root = FXMLLoader.load(getClass().getResource("/fxml/UnlinkCreditDebitCards.fxml"));
		      }
		 */		else if(event.getSource()==addPayee){
			 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			 root = FXMLLoader.load(getClass().getResource("/fxml/AddPayee.fxml"));
		 }

		 else if(event.getSource()==removePayee){
			 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
			 root = fxmlLoader.load();

			 RemovePayeeController controller = fxmlLoader.<RemovePayeeController>getController();
			 controller.initData(labelWelcomeMessage.getText().toString());

		 }
		 else if(event.getSource()==addVirtualCard){
			 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/AddVirtualCard.fxml"));
			 root = fxmlLoader.load();

			 AddVirtualCardController controller = fxmlLoader.<AddVirtualCardController>getController();
			 controller.initData(labelWelcomeMessage.getText().toString());
		 }
		//create a new scene with root and set the stage
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void saveCard(ActionEvent event){
		try{
			VirtualCard vCard = new VirtualCard();

			vCard.setNumber1(Long.parseLong(labelDigits1.getText().toString()));
			vCard.setNumber2(Long.parseLong(labelDigits2.getText().toString()));
			vCard.setNumber3(Long.parseLong(labelDigits3.getText().toString()));
			vCard.setNumber4(Long.parseLong(labelDigits4.getText().toString()));
			vCard.setMonth("02");
			vCard.setYear("2022");
			vCard.setFirstName(labelCardHolderName.getText().toString().toUpperCase());
			vCard.setCvv(Long.parseLong(labelCVV.getText().toString()));
			vCard.setAccountNumber(AccountHolderController.AccountNo);

			loginDatabaseOperations.insertVirtualCardNumber(vCard);
			
			if(loginDatabaseOperations.updateVirtualCardYN(AccountHolderController.AccountNo) == 0){
				System.out.println("Updated and Added");
				parseUserList();
			}
			
			btnAdd.setText("Remove");

		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
