package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import models.LoginDatabaseOperations;

public class CreateAccountController implements Initializable {
	
	@FXML
	private TextField textFirstName
						,textMiddleName
						,textLastName
						,textContact
						,textSSN
						,textEmail
						,textAddressLine1
						,textAddressLine2
						,textCity
						,textUsername
						,textPassword;
	
	@FXML
	private ComboBox<String> comboGender = new ComboBox();
	
	@FXML
	private DatePicker dpDOB;
	
	@FXML
	private ComboBox<String> comboState = new ComboBox();
	
/*	@FXML
	private CheckBox checkSavingAccount,checkCheckingAccount,checkInternetBanking;
*/
	@FXML
	private Button btnReset;
	@FXML
	private Button btnSave;
	
	private List<String> screenData = new ArrayList<>();
	private LoginDatabaseOperations loginDatabaseOperations;
	
	public List<String> FetchDataFromScreen(){
		
		screenData.add(0,textFirstName.getText());
		screenData.add(1,textMiddleName.getText());
		screenData.add(2,textLastName.getText());
		screenData.add(3,textContact.getText());
		screenData.add(4,textSSN.getText());
		screenData.add(5,textEmail.getText());
		screenData.add(6,textAddressLine1.getText()+","+textAddressLine2.getText()+","+textCity.getText());
		screenData.add(7,comboGender.getSelectionModel().getSelectedItem());
		screenData.add(8,comboState.getSelectionModel().getSelectedItem());
		screenData.add(9,textUsername.getText());
		screenData.add(10, textPassword.getText());
/*		checkInternetBanking.selectedProperty().addListener(new ChangeListener<Boolean>() {

			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				// TODO Auto-generated method stub
				screenData.add(11,newValue ? "enable": "disable");
			}
		});

		checkCheckingAccount.selectedProperty().addListener(new ChangeListener<Boolean>() {

			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				// TODO Auto-generated method stub
				screenData.add(12,newValue ? "enable": "disable");
			}
		});

		checkSavingAccount.selectedProperty().addListener(new ChangeListener<Boolean>() {

			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				// TODO Auto-generated method stub
				screenData.add(12,newValue ? "enable": "disable");
			}
		});
*/
		return screenData;
	}
	
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
        list.add("Alabama");
        list.add("Alaska");
        list.add("Arizona");
        list.add("Arkansas");
        list.add("California");
        list.add("Colorado");
        list.add("Connecticut");
        list.add("Delaware");
        list.add("Florida");
        list.add("Georgia");
        list.add("Hawaii");
        list.add("Idaho");
        list.add("Illinois");
        list.add("Indiana");
        list.add("Iowa");
        list.add("Kansas");
        list.add("Kentucky");
        list.add("Louisiana");
        list.add("Maine");
        list.add("Maryland");
        list.add("Massachusetts");
        list.add("Michigan");
        list.add("Minnesota");
        list.add("Mississippi");
        list.add("Missouri");

        ObservableList<String> obList = FXCollections.observableList(list);
        comboState.getItems().clear();
        comboState.setItems(obList);

		List<String> list2 = new ArrayList<String>();
        list2.add("Male");
        list2.add("Female");

        ObservableList<String> obList2 = FXCollections.observableList(list2);
        comboGender.getItems().clear();
        comboGender.setItems(obList2);

	}
	
	public void saveData(ActionEvent event){
		loginDatabaseOperations = new LoginDatabaseOperations();
		
		try{
			FetchDataFromScreen();
			int accountNumber = loginDatabaseOperations.saveData(screenData);
			System.out.println(" Account Created... Account Number : "+accountNumber);
			
			new Alert(Alert.AlertType.CONFIRMATION, "Account Created for Mr. "+ textLastName.getText()+ ". Please note down account number " +accountNumber+ " for future reference." ).showAndWait();
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
