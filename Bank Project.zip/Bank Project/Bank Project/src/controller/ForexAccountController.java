package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


import javafx.beans.value.ChangeListener;

import datamodels.Currency;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import models.LoginDatabaseOperations;

public class ForexAccountController implements Initializable {

	@FXML
	private MenuItem menuForexAccount, menuProfile,viewPayUpTransactions,transferFunds,linkCreditCards,unlinkCreditCards,addPayee,removePayee,addVirtualCard;
	@FXML
	private Label labelWelcomeMessage,labelCcyDetails;
	@FXML 
	private TableView<Currency> tableView;
	@FXML
	private ObservableList<Currency> currency;
	@FXML
	private TableColumn<Currency, String> ccyId;
	@FXML
	private TableColumn<Currency, String> ccyPair;
	@FXML
	private TableColumn<Currency, String> buyRate;
	@FXML
	private TableColumn<Currency, String> sellRate;
	@FXML
	private TextField txtCcy1,txtCcy2,txtAmount,txtEqAmt;
	@FXML
	private ComboBox<String> comboBuySell= new ComboBox();
	@FXML
	private Button btnConfirm,btnReset;
	@FXML
	private Stage stage;
	@FXML
	private Parent root;

	private String buysell;
	private ResultSet resultSet;
	private LoginDatabaseOperations loginDatabaseOperations;
	private List<Currency> currencies;
	private Currency rowData;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		loginDatabaseOperations = new LoginDatabaseOperations();

		/*tableView.setRowFactory(tv -> {
			TableRow<Currency> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
		            Currency rowData = row.getItem();
		            System.out.println(rowData);
		        }
			});
		});*/

		List<String> list = new ArrayList<String>();
		list.add("BUY");
		list.add("SELL");
		ObservableList<String> obList = FXCollections.observableList(list);
		comboBuySell.getItems().clear();
		comboBuySell.setItems(obList);

		tableView.setRowFactory(new Callback<TableView<Currency>, TableRow<Currency>>() {

			@Override
			public TableRow<Currency> call(TableView<Currency> tv) {
				TableRow<Currency> row = new TableRow<>();
				row.setOnMouseClicked(event -> {
					if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
						rowData = row.getItem();
						//System.out.println(rowData.getCurrencyPair());
						String ccyPair = rowData.getCurrencyPair();
						String currency[] = ccyPair.split(" - ");

						txtCcy1.setText(currency[0]);
						txtCcy2.setText(currency[1]);

						/*labelCcyDetails.setText("1 " +currency[0]+" = ");*/
					}
				});
				return row;
			}
		});
		
		comboBuySell.valueProperty().addListener(new ChangeListener<String>() {
	        @Override public void changed(ObservableValue ov, String t, String t1) {
	            System.out.println(t1);
	            
	            buysell = t1;
	        }    
	    });	
		
		txtAmount.textProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				// TODO Auto-generated method stub
				
				String pattern = "###,###.##";
				DecimalFormat decimalFormat = new DecimalFormat(pattern);
				
				if(buysell.equalsIgnoreCase("Buy")){
					Double multiply = Double.parseDouble(txtAmount.getText()) * Double.parseDouble(rowData.getCurrencyBuyRate());
					txtEqAmt.setText(String.valueOf(decimalFormat.format(multiply)));
					
					labelCcyDetails.setText("1 " +txtCcy1.getText()+" = " +rowData.getCurrencyBuyRate()+ " " +txtCcy2.getText());
				}
				else if(buysell.equalsIgnoreCase("Sell")){
					Double multiply = Double.parseDouble(txtAmount.getText()) * Double.parseDouble(rowData.getCurrencySellRate());
					txtEqAmt.setText(String.valueOf(decimalFormat.format(multiply)));
					
					labelCcyDetails.setText("1 " +txtCcy1.getText()+" = " +rowData.getCurrencySellRate()+ " " +txtCcy2.getText());
				}

			}
		});
	}

	public void parseUserList() {
		// TODO Auto-generated method stub		
		try {
			resultSet = loginDatabaseOperations.selectAllCurrencies();
			currencies = new ArrayList<>();
			currency = FXCollections.observableArrayList();
			Currency ccy;
			while(resultSet.next()){
				/*				currencies.add(0,resultSet.getString(1));
				currencies.add(1,resultSet.getString(2));
				cardList.add(2,resultSet.getString(3));
				cardList.add(3,resultSet.getString(4));
				 */			
				ccy =  new Currency(resultSet.getString(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4));				
				currency.add(ccy);
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ccyId.setCellValueFactory(new PropertyValueFactory<Currency,String>("currencyId"));
		ccyPair.setCellValueFactory(new PropertyValueFactory<Currency,String>("currencyPair"));
		buyRate.setCellValueFactory(new PropertyValueFactory<Currency,String>("currencyBuyRate"));
		sellRate.setCellValueFactory(new PropertyValueFactory<Currency,String>("currencySellRate"));
		tableView.setItems(currency);
	}

	public void initData(String string) {
		// TODO Auto-generated method stub
		labelWelcomeMessage.setText(string);
		parseUserList();
	}
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException, SQLException{
		if(event.getSource()==menuForexAccount){
			//get reference to the button's stage         
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			//load up OTHER FXML document
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
			root = fxmlLoader.load();
			ForexAccountController controller = fxmlLoader.<ForexAccountController>getController();
			controller.initData(labelWelcomeMessage.getText().toString());
		}
		else if(event.getSource()==menuProfile){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/ViewProfile.fxml"));
		}
		else if(event.getSource()==viewPayUpTransactions){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/PayUpTransactions.fxml"));
		}

		else if(event.getSource()==transferFunds){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/TransferFunds.fxml"));
		}
		else if(event.getSource()==linkCreditCards){
			stage=(Stage) labelWelcomeMessage.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("/fxml/LinkDebitCreditCards.fxml"));
		}

/*		else if(event.getSource()==unlinkCreditCards){
		       stage=(Stage) labelWelcomeMessage.getScene().getWindow();
		  root = FXMLLoader.load(getClass().getResource("/fxml/UnlinkCreditDebitCards.fxml"));
		      }
*/		else if(event.getSource()==addPayee){
		       stage=(Stage) labelWelcomeMessage.getScene().getWindow();
		  root = FXMLLoader.load(getClass().getResource("/fxml/AddPayee.fxml"));
		      }

else if(event.getSource()==removePayee){
    stage=(Stage) labelWelcomeMessage.getScene().getWindow();
	FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ForexAccount.fxml"));
	root = fxmlLoader.load();

	RemovePayeeController controller = fxmlLoader.<RemovePayeeController>getController();
	controller.initData(labelWelcomeMessage.getText().toString());

   }
else if(event.getSource()==addVirtualCard){
	 stage=(Stage) labelWelcomeMessage.getScene().getWindow();
	 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/AddVirtualCard.fxml"));
	 root = fxmlLoader.load();

	 AddVirtualCardController controller = fxmlLoader.<AddVirtualCardController>getController();
	 controller.initData(labelWelcomeMessage.getText().toString());
}

		//create a new scene with root and set the stage
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
}