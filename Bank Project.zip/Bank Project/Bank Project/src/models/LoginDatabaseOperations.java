package models;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import datamodels.VirtualCard;

public class LoginDatabaseOperations {

	private int returnCode = -1;
	private PreparedStatement preparedStatement;
	private	ResultSet resultSet = null;
	private StringBuilder queryBuilder = new StringBuilder();
	private Connection conn;
	private Connector connection;

	public LoginDatabaseOperations() {
		connection = new Connector();
	}
	
/*	public int createTable(){
		try{

			conn = connection.getConn();
			if(conn != null){
				System.out.println("Connected");

				resultSet = dataBaseMetaData.getTables(null, null, "Customer_Details", null);
				while(resultSet.next()){
					if(resultSet.getString("TABLE_NAME").equalsIgnoreCase("Customer_Details"))
					{
						queryBuilder.append(" DROP TABLE customer_details;");
						preparedStatement = conn.prepareStatement(queryBuilder.toString());				
						preparedStatement.executeUpdate(queryBuilder.toString());
						break;
					}
				}

				queryBuilder = new StringBuilder();
				queryBuilder.append(" CREATE TABLE IF NOT EXISTS LOGIN ");
				queryBuilder.append(" ( ");
				queryBuilder.append(" _id int(4) AUTO_INCREMENT PRIMARY KEY, ");
				queryBuilder.append(" username varchar(50) NOT NULL, ");
				queryBuilder.append(" password varchar(50) NOT NULL "); 
				queryBuilder.append(" ); ");	

				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());				
				returnCode = preparedStatement.executeUpdate(queryBuilder.toString()); //

				preparedStatement.close();
				
				System.out.println("Table Created Successfully...");
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return returnCode;
	}
*/	
	public ResultSet selectData(String username){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" select password,active_yn from LOGIN ");
				queryBuilder.append(" where username = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, username);
				resultSet = preparedStatement.executeQuery();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultSet;
	}
	
	public ResultSet selectParticularRecord(String username){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" select FirstName,LastName,AccountNo from account");
				queryBuilder.append(" where username = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, username);
				resultSet = preparedStatement.executeQuery();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultSet;
	}
	
	public int updateLoginTableAfterMaxAttempts(String username){
		try{
			returnCode = -1;
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" update LOGIN ");
				queryBuilder.append(" set active_yn = 'N', updated_by = 'sys_admin', updated_at = (SELECT CURRENT_TIMESTAMP)");
				queryBuilder.append(" where username = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, username);

				returnCode = preparedStatement.executeUpdate();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return returnCode;
	}
	
	public int updateLoginTableToActivate(String username){
		try{
			returnCode = -1;
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" update LOGIN ");
				queryBuilder.append(" set active_yn = 'Y', updated_by = 'admin', updated_at = (SELECT CURRENT_TIMESTAMP)");
				queryBuilder.append(" where username = ?");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, username);
				returnCode = preparedStatement.executeUpdate(queryBuilder.toString());
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return returnCode;
	}
	
	public int saveData(List<String> values){
		try{
			returnCode = -1;
			conn = connection.getConn();
			resultSet = null;
			if(conn != null){
				queryBuilder = new StringBuilder();
				queryBuilder.append("INSERT INTO account (FirstName,MiddleName,LastName,Contact,SSN,Email,Address,Gender,State,Username) values (?,?,?,?,?,?,?,?,?,?) ");
				preparedStatement = (PreparedStatement)conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, values.get(0));
				preparedStatement.setString(2, values.get(1));
				preparedStatement.setString(3, values.get(2));
				preparedStatement.setString(4, values.get(3));
				preparedStatement.setString(5, values.get(4));
				preparedStatement.setString(6, values.get(5));
				preparedStatement.setString(7, values.get(6));
				preparedStatement.setString(8, values.get(7));
				preparedStatement.setString(9, values.get(8));
				preparedStatement.setString(10, values.get(9));

				preparedStatement.execute();
				preparedStatement.close();
				queryBuilder = new StringBuilder();

				SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
			    Date now = new Date();
			    String strDate = sdfDate.format(now);

				queryBuilder.append("INSERT INTO LOGIN (username,password,no_of_attempts,created_at,created_by,updated_by,updated_at,active_yn) values (?,?,?,?,?,?,?,?) ");
				preparedStatement = (PreparedStatement)conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, values.get(9));
				preparedStatement.setString(2, getMD5(values.get(10)));
				preparedStatement.setInt(3, 3);
				preparedStatement.setString(4, strDate);
				preparedStatement.setString(5, "admin");
				preparedStatement.setString(6, "admin");
				preparedStatement.setString(7, strDate);
				preparedStatement.setString(8, "Y");
				preparedStatement.execute();
				preparedStatement.close();
				
				queryBuilder = new StringBuilder();
				queryBuilder.append(" select AccountNo from Account");
				queryBuilder.append(" where ssn = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, values.get(4));
				resultSet = preparedStatement.executeQuery();
				
				while(resultSet.next()){
					returnCode = resultSet.getInt(1);
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return returnCode;
		
	}
	
	
	public static String getMD5(String input) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			byte[] message = messageDigest.digest(input.getBytes());
			BigInteger number = new BigInteger(1, message);
			String hashtext = number.toString(16);
			// Now we need to zero pad it if you actually want the full 32 chars.
			while (hashtext.length() < 32) {
				hashtext = "0" + hashtext;
			}
			return hashtext;
		}
		catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}
	
	public boolean insertCreditCard(List<String> creditCard){
		boolean returnTF = false;
		try{		
			conn = connection.getConn();
			resultSet = null;
			if(conn != null){
				queryBuilder = new StringBuilder();
				queryBuilder.append("INSERT INTO carddetails (creditcardnumber,cvvnumber,nameoncard,expiry,alias,cardtype,accountno) values (?,?,?,?,?,?,?) ");
				preparedStatement = (PreparedStatement)conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, Long.parseLong(creditCard.get(0)));
				preparedStatement.setInt(2,  Integer.parseInt(creditCard.get(1)));
				preparedStatement.setString(3, creditCard.get(2));
				preparedStatement.setString(4, creditCard.get(3));
				preparedStatement.setString(5, creditCard.get(4));
				preparedStatement.setString(6, creditCard.get(5));
				preparedStatement.setInt(7, Integer.parseInt(creditCard.get(6)));

				returnTF = preparedStatement.execute();
				preparedStatement.close();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return returnTF;
	}
	
	public ResultSet selectAllCards(Long accountNo){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" select creditcardnumber,alias,cardtype,expiry from carddetails");
				queryBuilder.append(" where accountno = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, accountNo);
				resultSet = preparedStatement.executeQuery();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultSet;
	}
	
	public boolean insertPayee(List<String> payee){
		boolean returnTF = false;
		try{		
			conn = connection.getConn();
			resultSet = null;
			if(conn != null){
				queryBuilder = new StringBuilder();
				queryBuilder.append("INSERT INTO payee (PayeeName,PayeeAccountNo,PayeeNickName,PayeeContactNo,PayerAccountNo) values (?,?,?,?,?) ");
				preparedStatement = (PreparedStatement)conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setString(1, payee.get(0));
				preparedStatement.setLong(2,  Long.parseLong(payee.get(1)));
				preparedStatement.setString(3, payee.get(2));
				preparedStatement.setLong(4, Long.parseLong(payee.get(3)));
				preparedStatement.setLong(5, Long.parseLong(payee.get(4)));

				returnTF = preparedStatement.execute();
				preparedStatement.close();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return returnTF;
	}
	
	public ResultSet selectAllCurrencies(){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" select CcyPairID,CcyPair,CcyPairBidRate,CcyPairAskRate from rates");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				resultSet = preparedStatement.executeQuery();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultSet;
	}
	
	public ResultSet selectAllPayees(Long accountNo){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" select PayeeId,PayeeName,PayeeAccountNo,PayeeContactNo from payee where PayerAccountNo = ?");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, accountNo);
				resultSet = preparedStatement.executeQuery();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return resultSet;
	}
	
	public void deletePayeeRecord(Long payeeID){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" delete from payee where PayeeID = ?");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, payeeID);
				preparedStatement.execute();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public ResultSet getNewVirtualCardNumber(Long accountNo)
	{
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append(" SELECT FLOOR(RAND() * 10000) AS VIRTUALCARDNUMBER1,FLOOR(RAND() * 10000) AS VIRTUALCARDNUMBER2,FLOOR(RAND() * 10000) AS VIRTUALCARDNUMBER3,FLOOR(RAND() * 10000) AS VIRTUALCARDNUMBER4, FLOOR(RAND() * 1000) AS CVV, FirstName from account ");
				queryBuilder.append(" where accountNo = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, accountNo);
				resultSet = preparedStatement.executeQuery();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultSet;
	}
	public ResultSet getVirtualCardNumber(Long accountNo){
		try{
			conn = connection.getConn();
			if(conn!= null){
				
				queryBuilder = new StringBuilder();
				queryBuilder.append(" SELECT count(*) as Count,virtualcard1,virtualcard2,virtualcard3,virtualcard4,cvv,FirstName from virtualcards ");
				queryBuilder.append(" where AccNo = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, accountNo);
				resultSet = preparedStatement.executeQuery();					
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultSet;
	}
	
	public ResultSet getVirtualCardYN(Long accountNo){
		try{
			conn = connection.getConn();
			if(conn!= null){
				
				queryBuilder = new StringBuilder();
				queryBuilder.append(" SELECT virtualcardyn from account ");
				queryBuilder.append(" where AccountNo = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, accountNo);
				resultSet = preparedStatement.executeQuery();					
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultSet;
	}
	
	public int updateVirtualCardYN(Long accountNo){
		returnCode = -1;
		try{
			conn = connection.getConn();
			if(conn!= null){
				
				queryBuilder = new StringBuilder();
				queryBuilder.append(" update account set virtualcardyn = 'Y'  ");
				queryBuilder.append(" where AccountNo = ? ");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, accountNo);
				returnCode = preparedStatement.executeUpdate();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return returnCode;
	}

	
	public void insertVirtualCardNumber(VirtualCard vCard){
		try{
			conn = connection.getConn();
			if(conn!= null){
				queryBuilder = new StringBuilder();
				queryBuilder.append("INSERT INTO virtualcards (virtualcard1,virtualcard2,virtualcard3,virtualcard4,cvv,expirymonth,expiryyear,FirstName,AccNo) VALUES (?,?,?,?,?,?,?,?,?)");
				preparedStatement = (PreparedStatement) conn.prepareStatement(queryBuilder.toString());
				preparedStatement.setLong(1, vCard.getNumber1());
				preparedStatement.setLong(2, vCard.getNumber2());
				preparedStatement.setLong(3, vCard.getNumber3());
				preparedStatement.setLong(4, vCard.getNumber4());
				preparedStatement.setLong(5, vCard.getCvv());
				preparedStatement.setString(6, vCard.getMonth());
				preparedStatement.setString(7, vCard.getYear());
				preparedStatement.setString(8, vCard.getFirstName());
				preparedStatement.setLong(9, vCard.getAccountNumber());
				preparedStatement.execute();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void closeConnection(){
		try{
			conn.close();
		}catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}